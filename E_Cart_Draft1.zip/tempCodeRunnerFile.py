
    def checkout(self):